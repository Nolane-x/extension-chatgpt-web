import { ui,command,toast,syncHeader } from './model.js';
import { render } from './views.js';
import { createTaskActionController } from './task-actions.js';

const taskController=createTaskActionController({ui,command,toast});

async function refresh({quiet=false}={}){
  if(ui.loading)return;ui.loading=true;
  try{
    ui.dashboard=await command('getDashboardState');
    await taskController.refreshTaskData({detail:Boolean(ui.selectedTaskId)});
    if(ui.view==='microscope'&&Number.isInteger(Number(ui.selectedTabId))){
      const observed=await command('observe',{tabId:Number(ui.selectedTabId),includeContext:true}).catch(()=>null);
      if(observed?.context)ui.context=observed.context;
    }
    ui.lastRefreshAt=Date.now();syncHeader();await render();
  }catch(error){if(!quiet)toast(error.message,true);syncHeader(false);}finally{ui.loading=false;}
}
async function openMicroscope(tabId){ui.selectedTaskId=null;ui.taskDetail=null;ui.taskRecovery=null;ui.selectedTabId=tabId;ui.view='microscope';ui.context=null;ui.diagnostic=null;await render();try{const observed=await command('observe',{tabId,includeContext:true});ui.context=observed.context||null;ui.diagnostic=await command('diagnose',{tabId});await render();}catch(error){toast(error.message,true);}}
function nestedPatch(key,value){const s=ui.dashboard.settings||{};if(key==='recovery.enabled')return {recovery:{...(s.recovery||{}),enabled:value}};if(key==='handoff.enabled')return {handoff:{...(s.handoff||{}),enabled:value}};if(key==='watchdog.enabled')return {watchdog:{...(s.watchdog||{}),enabled:value}};return {[key]:value};}
function clearField(id){const field=document.getElementById(id);if(field)field.value='';}
async function enableAutomationEngine(){if(!ui.dashboard.settings?.automationsEnabled||ui.dashboard.settings?.automationPaused)await command('updateSettings',{patch:{automationsEnabled:true,automationPaused:false}});}

async function handleAction(target){
  const action=target.dataset.action;if(!action)return;
  try{
    if(action.startsWith('task-')){const handled=await taskController.handle(target);if(handled){syncHeader();await render();return;}}
    const tabId=Number(target.dataset.tab);
    if(action==='open-chat')await command('openChat',{});
    else if(action==='focus')await command('focusTab',{tabId});
    else if(action==='diagnose'){ui.diagnostic=await command('diagnose',{tabId});toast(`Diagnostic: ${ui.diagnostic.session?.health?.level||'ok'}`);if(ui.view==='microscope')await render();}
    else if(action==='microscope')return openMicroscope(tabId);
    else if(action==='queue'){const text=prompt('Prompt sẽ được gửi khi phiên an toàn:');if(text)await command('queueSend',{tabId,text,source:'user'});}
    else if(action==='queue-from-detail'){
      const field=document.getElementById('microscopeQueue'),text=field?.value?.trim();if(!text)throw new Error('Prompt tiếp theo đang trống.');
      await command('queueSend',{tabId,text,source:'user'});if(field)field.value='';toast('Đã thêm vào Safe Queue.');
    }
    else if(action==='automation-after-complete'){
      const field=document.getElementById('microscopeQueue'),text=field?.value?.trim();if(!text)throw new Error('Prompt tiếp theo đang trống.');
      const id=crypto.randomUUID();
      await command('saveAutomation',{rule:{id,name:`Tab ${tabId}: COMPLETED → send`,enabled:true,trigger:'state',whenState:'COMPLETED',tabId,delayMs:350,maxRuns:1,runCount:0,cooldownMs:2000,requireConfidence:.9,action:{type:'send',text}}});
      await enableAutomationEngine();if(field)field.value='';toast('Đã bật automation một lần: gửi prompt khi phiên HOÀN TẤT.');
    }
    else if(action==='stop'){await command('stop',{tabId});toast('Đã gửi lệnh dừng turn.');}
    else if(action==='retry'){const result=await command('retry',{tabId});toast(`Retry đã được lên lịch lúc ${new Date(result.dueAt).toLocaleTimeString()}.`);}
    else if(action==='handoff'){const result=await command('continueNewChat',{tabId});toast(`Đã handoff sang tab ${result.newTabId}.`);}
    else if(action==='download')await command('downloadArtifact',{tabId,artifactId:target.dataset.artifact});
    else if(action==='download-all')await command('downloadAllArtifacts',{tabId});
    else if(action==='open-artifact'&&target.dataset.href)await chrome.tabs.create({url:target.dataset.href,active:true});
    else if(action==='cancel-queue')await command('cancelQueued',{queueId:target.dataset.queue});
    else if(action==='toggle-rule')await command('setAutomationEnabled',{ruleId:target.dataset.rule,enabled:target.dataset.enabled!=='1'});
    else if(action==='create-rule'){
      const text=document.getElementById('rulePrompt')?.value?.trim();if(!text)throw new Error('Prompt automation đang trống.');
      const trigger=document.getElementById('ruleTrigger')?.value||'state';
      const tab=Number(document.getElementById('ruleTab')?.value);if(!Number.isInteger(tab)||tab<=0)throw new Error('Hãy chọn một tab ChatGPT đích.');
      const maxRuns=Math.max(1,Number(document.getElementById('ruleMaxRuns')?.value)||1),delayMs=Math.max(0,Number(document.getElementById('ruleDelay')?.value)||0)*1000;
      const rule={id:crypto.randomUUID(),name:'',enabled:true,trigger,tabId:tab,maxRuns,runCount:0,cooldownMs:2000,action:{type:'send',text}};
      if(trigger==='time'){
        const raw=document.getElementById('ruleRunAt')?.value,runAt=new Date(raw||'').getTime();if(!Number.isFinite(runAt)||runAt<Date.now()+1000)throw new Error('Hãy chọn thời gian trong tương lai.');
        rule.runAt=runAt;rule.maxRuns=1;rule.name=`Tab ${tab}: ${new Date(runAt).toLocaleString()} → send`;
      }else{
        const state=document.getElementById('ruleState')?.value||'COMPLETED';rule.whenState=state;rule.delayMs=delayMs;rule.requireConfidence=.7;rule.name=`Tab ${tab}: ${state} → send`;
      }
      await command('saveAutomation',{rule});
      if(document.getElementById('ruleEnableEngine')?.checked!==false)await enableAutomationEngine();
      clearField('rulePrompt');toast(trigger==='time'?'Đã lên lịch prompt theo thời gian.':'Đã tạo automation theo trạng thái.');
    }
    else if(action==='toggle-bridge')await command('updateSettings',{patch:{bridgeEnabled:!ui.dashboard.settings.bridgeEnabled}});
    else if(action==='setting-toggle'){const key=target.dataset.key,current=key.includes('.')?key.split('.').reduce((obj,k)=>obj?.[k],ui.dashboard.settings):ui.dashboard.settings?.[key];await command('updateSettings',{patch:nestedPatch(key,!current)});}
    else if(action==='delete-context'){if(confirm('Xóa Context Vault của phiên này?')){await command('deleteContext',{tabId});ui.context={timeline:[]};}}
    else if(action==='back'){ui.view='overview';ui.selectedTabId=null;ui.context=null;ui.diagnostic=null;return render();}
    await refresh({quiet:true});
  }catch(error){toast(error.message,true);}
}
function install(){
  document.getElementById('openChat').addEventListener('click',async()=>{try{await command('openChat',{});await refresh({quiet:true});}catch(e){toast(e.message,true);}});
  document.getElementById('toggleDeep').addEventListener('click',async()=>{try{await command('updateSettings',{patch:{deepObserve:!ui.dashboard.settings.deepObserve}});await refresh({quiet:true});}catch(e){toast(e.message,true);}});
  document.getElementById('togglePause').addEventListener('click',async()=>{try{const enabled=Boolean(ui.dashboard.settings.automationsEnabled&&!ui.dashboard.settings.automationPaused);await command('updateSettings',{patch:{automationsEnabled:!enabled,automationPaused:false}});await refresh({quiet:true});}catch(e){toast(e.message,true);}});
  document.querySelector('.nav-rail').addEventListener('click',(event)=>{const item=event.target.closest('.nav-item');if(!item)return;ui.view=item.dataset.view;ui.selectedTabId=null;ui.selectedTaskId=null;ui.taskDetail=null;ui.taskRecovery=null;ui.context=null;ui.diagnostic=null;render();});
  document.getElementById('viewRoot').addEventListener('click',(event)=>{const target=event.target.closest('[data-action]');if(target)handleAction(target);});
  document.getElementById('viewRoot').addEventListener('change',async(event)=>{try{if(event.target.id==='languageSelect')await command('updateSettings',{patch:{locale:event.target.value}});else if(event.target.id==='retentionMode')await command('updateSettings',{patch:{retentionMode:event.target.value}});else if(event.target.id==='retentionDays')await command('updateSettings',{patch:{retentionDays:Number(event.target.value)}});else if(event.target.matches('[data-scope]')){const scopes=[...document.querySelectorAll('[data-scope]:checked')].map((n)=>n.dataset.scope);await command('updateSettings',{patch:{agentScopes:scopes}});}else return;await refresh({quiet:true});}catch(error){toast(error.message,true);}});
  chrome.runtime.onMessage.addListener((message)=>{if(message?.type==='sentinel.dashboardUpdated'){clearTimeout(window.__sentinelRefresh);window.__sentinelRefresh=setTimeout(()=>refresh({quiet:true}),90);}});
}
export function bootstrapSidepanel(){install();refresh();setInterval(()=>refresh({quiet:true}),2500);}
